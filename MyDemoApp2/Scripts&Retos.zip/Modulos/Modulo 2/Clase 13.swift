//
//  Clase 13.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 13/11/24.
//

/// Agregar circulo
/// Explicar que son
/// Mostrar onTapGesture comparar con Button
/// Mostrar count
/// onLongPressGesture
/// minimumDuration
/// Mostrar DragGesture
/// 

// MARK: Slides
// Introduccion a para que sirven los gestos con gifs?
