//
//  Clase 11.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 13/11/24.
//

/// Mostrar el screen del formulario que quiero crear (notas)
/// Uno por uno agregar los componentes


/// Slide del form que queremos crear
