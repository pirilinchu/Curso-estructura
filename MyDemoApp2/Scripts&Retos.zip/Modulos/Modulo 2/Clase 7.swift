//
//  Clase 7.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 13/11/24.
//

// MARK: SCRIPT
/// Mostrar Button View con texto print("something")
/// Agregar parametro text junto con su Text(text), tirar error de inmutable con let cambiar a var
/// llevar func a una func
/// cambiar text to value
/// Bring NButton and make it UI
/// Add the isValid y volver a la implementacion e intentar y mostrar que no hace nada y arreglar
/// Terminar Button no olvidarse del disabled(!isValid)
/// Reto agregar -1 button
