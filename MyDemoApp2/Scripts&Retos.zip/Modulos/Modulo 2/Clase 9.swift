//
//  Clase 9.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 13/11/24.
//

/// Crear date picker con padding
/// Mostrar datePickerStyle
/// displayComponents
/// Picker de categoria
/// Picker de tamaños
/// 
