//
//  Clase 14.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 13/11/24.
//


/// VStack con dos circulos de 200
/// ShowGreen default
/// ShowGreen con transition
/// .slide
/// .scale
/// .move
/// .asymetric .slide, .scale
/// Show animation en form
/// Con esto finalizamos el modulo de UI
