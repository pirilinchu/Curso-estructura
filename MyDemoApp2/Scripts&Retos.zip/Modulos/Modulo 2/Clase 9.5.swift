//
//  Clase 10.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 13/11/24.
//

/// Crear Slider de edad
/// formatted number
/// Mostrar step
/// Crear Toggle
/// Mostrar toggleStyle
/// Agregar validacion age >= 18
