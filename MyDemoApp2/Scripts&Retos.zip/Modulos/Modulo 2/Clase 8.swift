//
//  Class 8.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 13/11/24.
//

// MARK: SCRIPT
/// Crear Textfield para Nombre
/// Personalizar
/// Mostrar onChange
/// Agregar validaciones
/// Mostrar TextEditor
/// 
