//
//  Clase 21.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 14/11/24.
//

/// Agregar funcionalidad de make Favorite a la card
/// Conectar Card con Lista y AppInfo
/// Agregar AppIcon en los assets eliminar las demas variantes
/// Mostrar AppIconReference en la configuracion del proyecto
/// Mostrar configuraciones basicas
