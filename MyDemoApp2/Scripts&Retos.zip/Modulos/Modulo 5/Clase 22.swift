//
//  Clase 22.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 14/11/24.
//

/// Hacer correr la app
/// Hacer correr en iPad
/// Mostrar las diferencias
/// Recapitular todo lo aprendido
///
