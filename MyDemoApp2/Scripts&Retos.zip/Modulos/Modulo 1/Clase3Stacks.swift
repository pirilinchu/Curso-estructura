//
//  Clase 3 Stacks.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 13/11/24.
//

// MARK: SCRIPT
// Explicar los stacks con slides
// Partir de una estructura conocida

// Explicar el VStack implicito, cambiar el alignment y luego el spacing
// Cambiar a HStack, agregar background, height al ultimo elemento y cambiar el alignment
// Cambiar a ZStack, cambiar por figuras cada vez mas pequeñas y de distintos colores
// Juntar todos
// Reto crear card
// Dentro de los recursos estara mi solucion

// MARK: Slides
// Stacks
// Slide del reto


import SwiftUI

struct Clase3Antes: View {
    var body: some View {
        ZStack(alignment: .center) {
            Color.green
                .padding(12)
            Circle()
                .frame(width: 500, height: 500)
            HStack(spacing: 0) {
                Rectangle()
                    .frame(width: 200, height: 100)
                    .foregroundStyle(Color.yellow)
                Rectangle()
                    .frame(width: 200, height: 100)
                    .foregroundStyle(Color.green)
            }
            VStack {
                Text("Esto es una")
                Text("Prueba")
            }
        }
        .background(Color.red)
    }
}

#Preview {
    Clase3Antes()
}

struct Clase3Despues: View {

    var body: some View {
        VStack {
            VStack(alignment: .center) {
                Text("Hola")
                Text("Mundo")
                Text("Esta")
                Text("Es")
                Text("Una")
                Text("Prueba")
            }
            HStack(alignment: .center) {
                Text("Hola")
                Text("Mundo")
                Text("Esta")
                Text("Es")
                Text("Una")
                Text("Prueba")
                    .frame(height: 100)
            }
            .background(Color.red)
            ZStack(alignment: .center) {
                Color.green
                    .padding(12)
                Circle()
                    .frame(width: 500, height: 500)
                Rectangle()
                    .frame(width: 200, height: 100)
                    .foregroundStyle(Color.yellow)
                Text("Prueba")
            }
            .background(Color.red)
            ZStack(alignment: .center) {
                Color.green
                    .padding(12)
                Circle()
                    .frame(width: 500, height: 500)
                HStack(spacing: 0) {
                    Rectangle()
                        .frame(width: 200, height: 100)
                        .foregroundStyle(Color.yellow)
                    Rectangle()
                        .frame(width: 200, height: 100)
                        .foregroundStyle(Color.green)
                }
                VStack {
                    Text("Esto es una")
                    Text("Prueba")
                }
            }
            .background(Color.red)
        }
    }

}
