//
//  Clase 16.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 13/11/24.
//

/// Add AppInfo para alojar las notas en el contentView
///
/// Slides tal vez mostrar una diferencia entre el AppInfo y el ViewModel
