//
//  Clase 17.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 13/11/24.
//

/// Explicar que es binding (un lazo entre vistas)
/// Crear el componente NTextField
/// Incentivar a cambiar TextEditor a componente reutilizable
