//
//  Clase 15.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 13/11/24.
//

/// Create Folder
/// Create ViewModel
/// Explain ObservableObject
/// Bring @States and convert to @Published
/// Refactor
