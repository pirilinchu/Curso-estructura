//
//  Clase 20.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 14/11/24.
//

/// Slide mostrando la funcionalidad que busco con el TabView y favoritos (Separar en dos listas)
/// Implementar TabView mostrar .tabItem Label
/// tabViewStyle
/// .toolbarBackground(Color.red, for: .tabBar)
/// toolbarBackgroundVisibility
/// Funcionalidad forFavorites en lista, arreglar separators
