//
//  Clase 18.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 13/11/24.
//

/// Explicar que queremos implementar una navegacion a una vista de detalle
/// Crear una vista de detalle
/// Wrappear con el NavigationStack
/// Implementar Button con el selectedCard
/// En la siguiente clase haremos uso del Toolbar
/// Personaliza la vista de detalle y comparte
