//
//  Clase 19.swift
//  MyDemoApp2
//
//  Created by Santiago Mendoza on 13/11/24.
//

// Slide con el navigation toolbar
// Mostrar modifieres de navegacion
// Cambiar titulo
// Agregar botones
// Mostrar navigationBackButtonHidden
// Mostrar toolbar { ToolbarItem }
